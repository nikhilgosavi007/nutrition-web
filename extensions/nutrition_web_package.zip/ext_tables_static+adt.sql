#
# Add Static SQL tables
#
